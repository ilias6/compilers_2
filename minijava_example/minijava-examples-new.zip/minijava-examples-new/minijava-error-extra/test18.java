class test18{
    public static void main(String[] a){
        System.out.println(new Test().start());
    }
}

class Test{
	
    public int start(){

        int op;
        int result;

        result = op[10];	// TE

        return 0;
    }
}
