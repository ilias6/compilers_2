class Add {
	public static void main(String[] a){
		System.out.println(12 + 21);
	}
}
